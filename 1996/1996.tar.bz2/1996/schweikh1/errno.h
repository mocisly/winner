extern int errno;
